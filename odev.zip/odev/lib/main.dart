import 'package:flutter/material.dart';

void main() {
  //soru 1 orjinal netindeki çift sayıların sayısını bulma
  // Orijinal dizi
  List<int> numbers = [5, 10, 15, 20, 25];

  // Çift sayıların sayısını tutacak değişken
  int ciftSayiSayisi = 0;

  // Dizideki her bir elemanı kontrol et
  for (int number in numbers) {
    if (number % 2 == 0) { // Çift sayıları kontrol et
      ciftSayiSayisi++; // Çift sayılar için sayacı artır
    }
  }

  // Sonucu ekrana bastır
  print('Dizideki çift sayıların sayısı: $ciftSayiSayisi');
}





